package com.cg.hbms.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.hbms.dao.HotelDaoImpl;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;

public class TestDao {
	static HotelDaoImpl hotelDaoImpl;
	static UsersDto usersDto;
	static HotelDto hotelDto;
	static RoomDetailsDto roomDto;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		hotelDaoImpl = new HotelDaoImpl();
		usersDto = new UsersDto();
		hotelDto = new HotelDto();
		roomDto = new RoomDetailsDto();
	}

	@Test
	public void testAddUsers() throws HotelException {
		usersDto.setPassword("rohit123");
		usersDto.setRole("Customer");
		usersDto.setUserName("Rohit");
		usersDto.setMobileNo("8098765677");
		usersDto.setPhone("011-2345672");
		usersDto.setAddress("Mumbai");
		usersDto.setEmail("rohit@gmail.com");
		assertTrue("Data not Inserted", hotelDaoImpl.registerUser(usersDto)==true);
		
	}
	
	@Test
	public void testAddHotels() throws HotelException {
		hotelDto.setHotelName("Grand");
		hotelDto.setAvgRatePerNight(2000);
		hotelDto.setAddress("Thane");
		hotelDto.setCity("Mumbai");
		hotelDto.setDescription("3 star");
		hotelDto.setEmail("g@gmail.com");
		hotelDto.setFax("098-678-5436");
		hotelDto.setPhoneNo1("098-6785436");
		hotelDto.setPhoneNo2("094-4363436");
		hotelDto.setRating("4");
		assertTrue("Data not Inserted", hotelDaoImpl.addHotel(hotelDto)==true);
		
	}
	
	@Test
	public void testdeleteHotel() throws HotelException {
		assertNotNull(hotelDaoImpl.deleteHotelById("103"));
	}
	
	@Ignore
	@Test
	public void testdeleteHotel1() throws HotelException {
		assertNotNull(hotelDaoImpl.deleteHotelById("1001"));
	}
	
	
	@Test
	public void testmodifyHotel() throws HotelException {
		assertNotNull(hotelDaoImpl.modifyHotelById("103","7 Star"));
	}
	
	@Ignore
	@Test
	public void testmodifyHotel1() throws HotelException {
		assertNotNull(hotelDaoImpl.modifyHotelById("1001","7 Star"));
	}
	

	@Test
	public void testAddRooms() throws HotelException {
		roomDto.setRoomNo("108");
		roomDto.setRoomType("Standard AC");
		roomDto.setAvailability(false);
		roomDto.setPerNightRate(3000);
		roomDto.setHotelId("110");
		assertTrue("Data not Inserted", hotelDaoImpl.addRoom(roomDto)==true);
		
	}
	
	
	@Test
	public void testdeleteRoom() throws HotelException {
		assertNotNull(hotelDaoImpl.deleteRoomById("103","24"));
	}
	
	@Ignore
	@Test
	public void testdeleteRoom1() throws HotelException {
		assertNotNull(hotelDaoImpl.deleteRoomById("103","54"));
	}
	

	@Test
	public void testmodifyRoom() throws HotelException {
		assertNotNull(hotelDaoImpl.modifyRoomById("103","24",2000));
	}
	
	@Ignore
	@Test
	public void testmodifyRoom1() throws HotelException {
		assertNotNull(hotelDaoImpl.modifyRoomById("103","54",2000));
	}

}
