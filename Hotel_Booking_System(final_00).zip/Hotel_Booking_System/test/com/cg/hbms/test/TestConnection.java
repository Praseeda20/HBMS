package com.cg.hbms.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;



import com.cg.hbms.exception.HotelException;
import com.cg.hbms.util.DBUtil;

public class TestConnection {

	
	@Test
	public void testConnection() throws HotelException {
		Connection con = DBUtil.getConnection();
		System.out.println(con);
		assertNotNull(con);
	}
	
	@Ignore
	@Test(expected = HotelException.class)
	public void testConnectionFailed() throws HotelException {
		Connection con = DBUtil.getConnection();
	}
}

