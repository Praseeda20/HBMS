package com.cg.hbms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.service.HotelService;
import com.cg.hbms.service.HotelServiceImpl;

/**
 * Servlet implementation class HotelController
 */
@WebServlet({ "/LoginPage", "/Login", "/Register", "/RegisterSuccess","/MainPage",
		"/ForwardAdmin","/HotelMgmnt","/AddHotel","/DeleteHotel","/ModifyHotelDetails",
		"/RoomMgmnt","/AddRoom","/DeleteRoom","/ModifyRoomDetails","/GenerateReports","/ViewHotels" ,"/ViewHotelList"})
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public HotelController() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		HttpSession session = request.getSession(true);
		List<String> hotelIdList = new ArrayList<String> ();
		String url = request.getServletPath();
		// String target = "";
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		HotelService hotelService = new HotelServiceImpl();
		UsersDto usersDto=new UsersDto();
		HotelDto hotelDto = new HotelDto();
		RoomDetailsDto roomDto = new RoomDetailsDto();
		BookingDetailsDto bookingDto = new BookingDetailsDto();
		switch (url) {
		case "/LoginPage":
			dispatcher = request.getRequestDispatcher("jspPages/login.jsp");
			dispatcher.forward(request, response);
				break;
				

		case "/Login":
			String password = request.getParameter("password");
			String role = request.getParameter("role");
			String userName = request.getParameter("userName");
			boolean isValidUser=false;
			try {
				usersDto.setPassword(password);
				usersDto.setRole(role);
				usersDto.setUserName(userName);
				isValidUser = hotelService.checkCredentials(usersDto);
			} catch (HotelException e) {
			e.printStackTrace();
			}	
			if(isValidUser){
			dispatcher = request.getRequestDispatcher("jspPages/mainPage.jsp");
			dispatcher.forward(request, response);
			}
			else{
				dispatcher = request.getRequestDispatcher("jspPages/errorPage.jsp");
				dispatcher.forward(request, response);
			}
				break;
				
		case "/Register":
			dispatcher = request.getRequestDispatcher("jspPages/register.jsp");
			dispatcher.forward(request, response);
				break;
				
		case "/RegisterSuccess":
			boolean isRegistered = false;
			String pass=request.getParameter("password");
			String userRole=request.getParameter("role");
			String userNames=request.getParameter("userName");	
			String mobileNo=request.getParameter("mobile");
			String phone=request.getParameter("phone");
			String address=request.getParameter("address");
			String email=request.getParameter("email");		
			try {
				usersDto.setPassword(pass);
				usersDto.setRole(userRole);
				usersDto.setUserName(userNames);
				usersDto.setMobileNo(mobileNo);
				usersDto.setPhone(phone);
				usersDto.setAddress(address);
				usersDto.setEmail(email);	
				isRegistered = hotelService.registerUser(usersDto);
					} catch (HotelException e) {
			e.printStackTrace();
			}	
			if(isRegistered){
			dispatcher = request.getRequestDispatcher("jspPages/RegisterSuccess.jsp");
			dispatcher.forward(request, response);
			}
			else{
			dispatcher = request.getRequestDispatcher("jspPages/errorPage.jsp");
			dispatcher.forward(request, response);
			}	
			break;
			
		case "/MainPage":
			dispatcher = request.getRequestDispatcher("jspPages/mainPage.jsp");
			dispatcher.forward(request, response);
				break;

		case "/ForwardAdmin":
			String hotelMgmnt = request.getParameter("hotelMgmnt");
			System.out.println(hotelMgmnt);
			if (hotelMgmnt != null && "HOTEL MANAGEMENT".equals(hotelMgmnt)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/HotelManagement.jsp");
				dispatcher.forward(request, response);
			}
			
			String roomMgmnt = request.getParameter("roomMgmnt");
			if (roomMgmnt != null && "ROOM MANAGEMENT".equals(roomMgmnt)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/RoomManagement.jsp");
				dispatcher.forward(request, response);
			}
			
			String generateRep = request.getParameter("generateRep");
			if (generateRep != null && "GENERATE REPORTS".equals(generateRep)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/GenerateReports.jsp");
				dispatcher.forward(request, response);
			}
			break;
			
		case "/HotelMgmnt":
			String addHotel = request.getParameter("addHotel");
			System.out.println(addHotel);
			if (addHotel != null && "ADD HOTEL".equals(addHotel)) {
			dispatcher = request.getRequestDispatcher("jspPages/addHotel.jsp");
			dispatcher.forward(request, response);
		}
			String deleteHotel = request.getParameter("deleteHotel");
			if (deleteHotel != null && "DELETE HOTEL".equals(deleteHotel)) {
			dispatcher = request.getRequestDispatcher("jspPages/deleteHotel.jsp");
			dispatcher.forward(request, response);
		}	
			String modifyHotel = request.getParameter("modifyHotel");
			if (modifyHotel != null && "MODIFY HOTEL".equals(modifyHotel)) {
			dispatcher = request.getRequestDispatcher("jspPages/modifyHotel.jsp");
			dispatcher.forward(request, response);
		}
			break;
			
		case "/RoomMgmnt":
			
			try {
				hotelIdList=hotelService.getHotelDetails();
				System.out.println("\n\nRoom Management\n\n"+hotelIdList);
				session.setAttribute("hotelIdList", hotelIdList);
			
			String addRoom = request.getParameter("addRoom");
			if (addRoom != null && "ADD ROOM".equals(addRoom)) {
				System.out.println("ADD ROOM ENTERED");
					dispatcher = request.getRequestDispatcher("jspPages/addRoom.jsp");
			dispatcher.forward(request, response);
		}
			String deleteRoom = request.getParameter("deleteRoom");
			if (deleteRoom != null && "DELETE ROOM".equals(deleteRoom)) {
			dispatcher = request.getRequestDispatcher("jspPages/deleteRoom.jsp");
			dispatcher.forward(request, response);
		}	
			String modifyRoom = request.getParameter("modifyRoom");
			if (modifyRoom != null && "MODIFY ROOM".equals(modifyRoom)) {
			dispatcher = request.getRequestDispatcher("jspPages/modifyRoom.jsp");
			dispatcher.forward(request, response);
		}
			} catch (HotelException e) {
				e.printStackTrace();
			}
			break;
			
		case "/GenerateReports":
			try {
				hotelIdList=hotelService.getHotelDetails();
				session.setAttribute("hotelIdList", hotelIdList);
				
			String viewHotelList = request.getParameter("viewHotelList");
			System.out.println("viewHotelList: "+viewHotelList);
			if (viewHotelList != null && "View List of Hotels".equals(viewHotelList)) {
			dispatcher = request.getRequestDispatcher("ViewHotelList");
			dispatcher.forward(request, response);
		}
			String viewSpecificHotelBooking = request.getParameter("viewSpecificHotelBooking");
			if (viewSpecificHotelBooking != null && "View Bookings of specific hotel".equals(viewSpecificHotelBooking)) {
			dispatcher = request.getRequestDispatcher("jspPages/viewBookingsOfHotel.jsp");
			dispatcher.forward(request, response);
		}	
			String viewGuestList = request.getParameter("viewGuestList");
			if (viewGuestList != null && "View guest list of specific hotel".equals(viewGuestList)) {
			dispatcher = request.getRequestDispatcher("jspPages/viewGuestList.jsp");
			dispatcher.forward(request, response);
		}
			String viewBookingsOnDate = request.getParameter("viewBookingsOnDate");
			if (viewBookingsOnDate != null && "View bookings for specified date".equals(viewBookingsOnDate)) {
			dispatcher = request.getRequestDispatcher("jspPages/viewBookingOfDate.jsp");
			dispatcher.forward(request, response);
		}
			} catch (HotelException e) {
			e.printStackTrace();
		}
		break;
			
		case "/AddHotel":
			boolean isInserted = false;
			String city=request.getParameter("city");
			String hotelName=request.getParameter("hotelName");
			String hotelAddress=request.getParameter("address");	
			String desc=request.getParameter("desc");
			double avgRatePerNight=Double.parseDouble(request.getParameter("avgNight"));
			String phone1=request.getParameter("phone1");
			String phone2=request.getParameter("phone2");		
			String rating=request.getParameter("rating");
			String emailId=request.getParameter("email");		
			String fax=request.getParameter("fax");	
			
			try {
				hotelDto.setCity(city);
				hotelDto.setHotelName(hotelName);
				hotelDto.setAddress(hotelAddress);
				hotelDto.setDescription(desc);
				hotelDto.setAvgRatePerNight(avgRatePerNight);
				hotelDto.setPhoneNo1(phone1);
				hotelDto.setPhoneNo2(phone2);
				hotelDto.setRating(rating);
				hotelDto.setEmail(emailId);
				hotelDto.setFax(fax);
				isInserted= hotelService.addHotel(hotelDto);
				System.out.println(isInserted);
			} catch (HotelException e) {
			e.printStackTrace();
			}	
			if(isInserted){
			dispatcher = request.getRequestDispatcher("jspPages/success.jsp");
			dispatcher.forward(request, response);
			}
			else{
			dispatcher = request.getRequestDispatcher("jspPages/errorPage.jsp");
			dispatcher.forward(request, response);
			}	
			break;
			
		case "/DeleteHotel":
			String hotelId=request.getParameter("hotelId");
			boolean isDeleted = false;
			try {
				isDeleted = hotelService.deleteHotelById(hotelId);
			} catch (HotelException e) {
				e.printStackTrace();
			}
			if(isDeleted){
				dispatcher = request.getRequestDispatcher("jspPages/success.jsp");
				dispatcher.forward(request, response);
				}
				else{
				dispatcher = request.getRequestDispatcher("jspPages/errorPage.jsp");
				dispatcher.forward(request, response);
				}	
				break;
				
		case "/ModifyHotelDetails":
			String hotelsId=request.getParameter("hotelId");
			String hotelDesc=request.getParameter("hotelDesc");
			boolean isModified=false;
			try {
				isModified = hotelService.modifyHotelById(hotelsId,hotelDesc);
			} catch (HotelException e) {
			e.printStackTrace();
			}
			if(isModified){
				dispatcher = request.getRequestDispatcher("jspPages/success.jsp");
				dispatcher.forward(request, response);
				}
				else{
				dispatcher = request.getRequestDispatcher("jspPages/errorPage.jsp");
				dispatcher.forward(request, response);
				}	
				break;
				
		case "/AddRoom":
			boolean isRoomInserted = false;			
			String hotel_Id=request.getParameter("hotelId");
			String roomNo=request.getParameter("roomNo");
			String roomType=request.getParameter("roomType");	
			double perNightRate=Double.parseDouble(request.getParameter("perNightRate"));
			boolean availabilty=Boolean.getBoolean(request.getParameter("availability"));
	
			try {
			roomDto.setHotelId(hotel_Id);
			roomDto.setRoomNo(roomNo);
			roomDto.setRoomType(roomType);
			roomDto.setPerNightRate(perNightRate);
			roomDto.setAvailability(availabilty);
			isRoomInserted= hotelService.addRoom(roomDto);
				System.out.println(isRoomInserted);
			} catch (HotelException e) {
			e.printStackTrace();
			}	
			if(isRoomInserted){
			dispatcher = request.getRequestDispatcher("jspPages/success.jsp");
			dispatcher.forward(request, response);
			}
			else{
			dispatcher = request.getRequestDispatcher("jspPages/errorPage.jsp");
			dispatcher.forward(request, response);
			}	
			break;
			
		case "/DeleteRoom":
			hotelId=request.getParameter("hotelId");
			String roomId=request.getParameter("roomId");
			isDeleted = false;
			try {
				isDeleted = hotelService.deleteRoomById(hotelId, roomId);
			} catch (HotelException e) {
				e.printStackTrace();
			}
			if(isDeleted){
				dispatcher = request.getRequestDispatcher("jspPages/success.jsp");
				dispatcher.forward(request, response);
				}
				else{
				dispatcher = request.getRequestDispatcher("jspPages/errorPage.jsp");
				dispatcher.forward(request, response);
				}	
				break;
				
		case "/ModifyRoomDetails":
			hotelId=request.getParameter("hotelId");
			roomId=request.getParameter("roomId");
			perNightRate=Double.parseDouble(request.getParameter("perNightRate"));
			
			isModified=false;
			try {
				isModified = hotelService.modifyRoomById(hotelId, roomId, perNightRate);
			} catch (HotelException e) {
			e.printStackTrace();
			}
			if(isModified){
				dispatcher = request.getRequestDispatcher("jspPages/success.jsp");
				dispatcher.forward(request, response);
				}
				else{
				dispatcher = request.getRequestDispatcher("jspPages/errorPage.jsp");
				dispatcher.forward(request, response);
				}	
				break;
				
		case "/ViewHotelList":
			List<HotelDto> hotelList = new ArrayList<HotelDto>();
			try {
				hotelList = hotelService.viewHotelList();
				session.setAttribute("hotelList", hotelList);
			} catch (HotelException e) {
				e.printStackTrace();
			}
						break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
