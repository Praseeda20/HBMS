package com.cg.hbms.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.hbms.dao.HotelDao;
import com.cg.hbms.dao.HotelDaoImpl;
import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;

public class HotelServiceImpl implements HotelService{
	HotelDao hotelDao = new HotelDaoImpl();
	//RoomDetailsDto roomDto = new RoomDetailsDto();
	@Override
	public boolean addHotel(HotelDto hotelDto) throws HotelException {
		return hotelDao.addHotel(hotelDto);
	}


	@Override
	public boolean deleteHotelById(String hotelId) throws HotelException {
		return hotelDao.deleteHotelById(hotelId);
	}

	@Override
	public boolean modifyHotelById(String hotelId, String hotelDesc) throws HotelException{
		return hotelDao.modifyHotelById(hotelId, hotelDesc);
	}

	@Override
	public boolean addRoom(RoomDetailsDto roomId) throws HotelException {
		return hotelDao.addRoom(roomId);
	}

	@Override
	public boolean deleteRoomById(String hotelId, String roomId) throws HotelException {
		return hotelDao.deleteRoomById(hotelId, roomId);
	}

	@Override
	public boolean modifyRoomById(String hotelId, String roomId,
			double perNightRate) throws HotelException {
		return hotelDao.modifyRoomById(hotelId, roomId, perNightRate);
	}
	
	@Override
	public ArrayList<HotelDto> viewHotelList() throws HotelException {
		return hotelDao.viewHotelList();
	}

	@Override
	public ArrayList<BookingDetailsDto> viewBookingListByDate(String booked_from)
			throws HotelException {
		return hotelDao.viewBookingListByDate(booked_from);
	}
	
	@Override
	public BookingDetailsDto viewBookingById(String hotelId) throws HotelException {
		return hotelDao.viewBookingById(hotelId);
	}

	@Override
	public ArrayList<UsersDto> viewGuestListByHotelId(String hotelId)
			throws HotelException {
		return hotelDao.viewGuestListByHotelId(hotelId);
	}

	@Override
	public boolean checkCredentials(UsersDto usersDto) throws HotelException {
		List<UsersDto> credentialsList = hotelDao.getUserCredentials();
		System.out.println(credentialsList);
		boolean validUser=false;
		for(UsersDto list : credentialsList){
			if(list.getUserName().equals(usersDto.getUserName()) && list.getPassword().equals(usersDto.getPassword()) && list.getRole().equals(usersDto.getRole())){
			validUser = true;	
			break;
		}
			
			}
	return validUser;
}
	@Override
	public boolean registerUser(UsersDto userDto) throws HotelException {
		return hotelDao.registerUser(userDto);
	}


	@Override
	public List<String> getHotelDetails() throws HotelException {
		return hotelDao.getHotelDetails();
	}

}


