package com.cg.hbms.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;

public interface HotelService {
	public boolean registerUser(UsersDto userDto) throws HotelException;
	
    public boolean addHotel(HotelDto hotelDto) throws HotelException;
	public boolean deleteHotelById(String hotelId) throws HotelException;
	public boolean modifyHotelById(String hotelId, String hotelDesc) throws HotelException;
	
	public boolean addRoom(RoomDetailsDto room) throws HotelException;
	public boolean deleteRoomById(String hotelId, String roomId) throws HotelException ;
	public boolean modifyRoomById(String hotelId,String roomId, double perNightRate) throws HotelException;
	
	public ArrayList<HotelDto> viewHotelList() throws HotelException;
	public ArrayList<BookingDetailsDto> viewBookingListByDate(String booked_from) throws HotelException;
	public BookingDetailsDto viewBookingById(String hotelId) throws HotelException;
	public ArrayList<UsersDto> viewGuestListByHotelId(String hotelId) throws HotelException;
	
	public boolean checkCredentials(UsersDto usersDto) throws HotelException;

	public List<String> getHotelDetails()throws HotelException;
	
}
