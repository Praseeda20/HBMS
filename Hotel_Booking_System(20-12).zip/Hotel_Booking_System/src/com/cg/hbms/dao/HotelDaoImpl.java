package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.util.DBUtil;

public class HotelDaoImpl implements HotelDao{
	HotelDto hotel =  new HotelDto();
	UsersDto usersDto =  new UsersDto();
	RoomDetailsDto roomDto= new RoomDetailsDto();
	
	@Override
	public boolean addHotel(HotelDto hotelDto) throws HotelException{
		boolean isInserted = false;
		int result = 0;
		
		try {
			Connection con = DBUtil.getConnection();
			String query="insert into hotel values(hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement preparedSt = con.prepareStatement(query);
				preparedSt.setString(1, hotelDto.getCity());
				preparedSt.setString(2, hotelDto.getHotelName());
				preparedSt.setString(3, hotelDto.getAddress());
				preparedSt.setString(4, hotelDto.getDescription());
				preparedSt.setDouble(5, hotelDto.getAvgRatePerNight());
				preparedSt.setString(6, hotelDto.getPhoneNo1());
				preparedSt.setString(7, hotelDto.getPhoneNo2());
				preparedSt.setString(8, hotelDto.getRating());
				preparedSt.setString(9, hotelDto.getEmail());
				preparedSt.setString(10, hotelDto.getFax());
				
				result = preparedSt.executeUpdate();
				if(result > 0){
					isInserted = true;
				}
				con.close();
		} catch (SQLException e) {

			throw new HotelException(e.getMessage());
			
		}catch(HotelException ue){
			throw new HotelException("Error while inserting records into database");
		}
		return isInserted;
	}

	@Override
	public boolean deleteHotelById(String hotelId) throws HotelException {
		Connection con = DBUtil.getConnection();
		boolean isDeleted=false;
		int result =0;
		String query="delete from hotel where hotel_id=(?)";
			try {
				PreparedStatement preparedSt = con.prepareStatement(query);
				preparedSt.setString(1, hotelId);
				System.out.println(hotelId);
				result = preparedSt.executeUpdate();
				if(result==1){
					isDeleted = true;
				}
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return isDeleted;		
	}

	@Override
	public boolean modifyHotelById(String hotelId, String hotelDesc) throws HotelException{
		Connection con = DBUtil.getConnection();
		boolean isModified=false;
		int result =0;
		String query="update hotel set description=? where hotel_id=?";
		try {
				PreparedStatement preparedSt = con.prepareStatement(query);
				preparedSt.setString(1, hotelDesc);
				preparedSt.setString(2, hotelId);
				System.out.println(hotelId);
				System.out.println(hotelDesc);		
				result = preparedSt.executeUpdate();
				
				System.out.println("ok");
				System.out.println(result);
				if(result>0){
					isModified = true;
				}
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return isModified;		
	}

	@Override
	public boolean addRoom(RoomDetailsDto roomDto) throws HotelException {
		Connection con = DBUtil.getConnection();
		int result=0;
		boolean isInserted=false;
		String sqlQuery = "insert into RoomDetails(hotel_id, room_id, room_no, room_type, per_night_rate, availability) "
				+ "values(?, room_id_seq.nextval, ?, ?, ?, ?)";
	
			try {
				PreparedStatement sqlStat=con.prepareStatement(sqlQuery);
				sqlStat.setString(1,roomDto.getHotelId());
				sqlStat.setString(2,roomDto.getRoomNo());
				sqlStat.setString(3,roomDto.getRoomType());
				sqlStat.setDouble(4,roomDto.getPerNightRate());
				sqlStat.setBoolean(5,roomDto.isAvailability());
				sqlStat.executeUpdate();
				result = sqlStat.executeUpdate();
				if(result > 0){
					isInserted = true;
				}
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	return isInserted;
	}

	@Override
	public boolean deleteRoomById(String hotelId, String roomId) throws HotelException {
       Connection con = DBUtil.getConnection();
		boolean isDeleted=false;
		int result =0;
		String query = "delete from RoomDetails where hotel_id =? and room_id =?";
			try {
				PreparedStatement preparedSt = con.prepareStatement(query);
				preparedSt.setString(1, hotelId);
				preparedSt.setString(2, roomId);
				result = preparedSt.executeUpdate();
				if(result==1){
					isDeleted = true;
				}
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return isDeleted;		
	}

	@Override
	public boolean modifyRoomById(String hotelId, String roomId, double perNightRate) throws HotelException {
		Connection con = DBUtil.getConnection();
		boolean isModified=false;
		int result =0;
		String query="update roomdetails set per_night_rate=? where hotel_id=? and room_id=?";
		try {
				PreparedStatement preparedSt = con.prepareStatement(query);
				preparedSt.setDouble(1, perNightRate);
				preparedSt.setString(2, hotelId);
				preparedSt.setString(3, roomId);	
				result = preparedSt.executeUpdate();
				if(result>0){
					isModified = true;
				}
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return isModified;
	}

	@Override
	public ArrayList<HotelDto> viewHotelList() throws HotelException {
		 Connection con = DBUtil.getConnection();
       ArrayList<HotelDto> hotelList = new ArrayList<HotelDto>();
		String sqlQuery = "select * from hotel";
		Statement stat=null;
		ResultSet res=null;
		
		try {
			
			stat=con.createStatement();
			res=stat.executeQuery(sqlQuery);
			
			while(res.next()) {
				
			    hotel.setHotelId(res.getString(1));
				hotel.setCity(res.getString(2));
				hotel.setHotelName(res.getString(3));
				hotel.setAddress(res.getString(4));
				hotel.setDescription(res.getString(5));
				hotel.setAvgRatePerNight(res.getDouble(6));
				hotel.setPhoneNo1(res.getString(7));
				hotel.setPhoneNo2(res.getString(8));
				hotel.setRating(res.getString(9));
				hotel.setEmail(res.getString(10));
				hotel.setFax(res.getString(11));	
				hotelList.add(hotel);
			}
		}
		catch (SQLException e) {
			throw new HotelException("Unable to fetch hotel records!!");
		}
		
		return hotelList;
	}

	@Override
	public ArrayList<BookingDetailsDto> viewBookingListByDate(String booked_from)
			throws HotelException {
		ArrayList<BookingDetailsDto> bookingList = new ArrayList<BookingDetailsDto>();
		Connection con = DBUtil.getConnection();
		BookingDetailsDto booking;
		ResultSet res=null;
		int result=0;
		try {
			String query = "select * from BookingDetails where booked_from =(?)";
			PreparedStatement preparedSt = con.prepareStatement(query);
			preparedSt.setString(1, booked_from);
			result = preparedSt.executeUpdate();
			while(res.next()) {
					
					booking = new BookingDetailsDto();
					
					booking.setBookingId(res.getString(1));
					booking.setRoomId(res.getString(2));
					booking.setUserId(res.getString(3));
					booking.setBookedFrom(res.getDate(4));
					booking.setBookedTo(res.getDate(5));
					booking.setNoOfAdults(res.getInt(6));
					booking.setNoOfChildren(res.getInt(7));
					booking.setAmount(res.getDouble(8));
					
					bookingList.add(booking);
				}
		} catch (SQLException e) {
			throw new HotelException("Unable to fetch Bookings!!");
				}
	
		
		return bookingList;
	}

	@Override
	public BookingDetailsDto viewBookingById(String hotelId) throws HotelException {
BookingDetailsDto booking = new BookingDetailsDto();
Connection con = DBUtil.getConnection();	
		String sqlQuery = "select * from BookingDetails where booking_id = (?)";
		Statement stat=null;
		ResultSet res=null;
		try {
			
			stat=(Statement) con.createStatement();
			res=((java.sql.Statement) stat).executeQuery(sqlQuery);
			
			while(res.next()) {

				booking.setBookingId(res.getString(1));
				booking.setRoomId(res.getString(2));
				booking.setUserId(res.getString(3));
				booking.setBookedFrom(res.getDate(4));
				booking.setBookedTo(res.getDate(5));
				booking.setNoOfAdults(res.getInt(6));
				booking.setNoOfChildren(res.getInt(7));
				booking.setAmount(res.getDouble(8));
			}
		}
		catch (SQLException e) {
			throw new HotelException("No booking found with  hotel id = " + hotelId);
		}
		
		return booking;
	}

	@Override
	public ArrayList<UsersDto> viewGuestListByHotelId(String hotelId)
			throws HotelException {
		ArrayList<Object> guest = new ArrayList<Object>();
		ArrayList<ArrayList<Object>> guestList = new ArrayList<ArrayList<Object>>();
		Connection con = DBUtil.getConnection();	

		UsersDto user;
		HotelDto hotel;
		RoomDetailsDto room;
		BookingDetailsDto booking;
		
		String sqlQuery = "select u.user_name, h.hotel_name, r.room_no, r.room_type, b.booked_from, b.booked_to"
				+ "from users u, hotel h, RoomDetails r, BookingDetails b where u.user_id = b.user_id, " + hotelId
				+ " = b.hotel_id, r.room_id = b.room_id";
		
		Statement stat=null;
		ResultSet res=null;
		
		try {
			
			stat=(Statement) con.createStatement();
			res=((java.sql.Statement) stat).executeQuery(sqlQuery);
			
			while(res.next()) {
				
				user = new UsersDto();
				hotel = new HotelDto();
				room  = new RoomDetailsDto();
				booking = new BookingDetailsDto();
				
				user.setUserName(res.getString(1));
				hotel.setHotelName(res.getString(2));
				room.setRoomNo(res.getString(3));
				room.setRoomType(res.getString(4));
				booking.setBookedFrom(res.getDate(5));
				booking.setBookedTo(res.getDate(6));
				
				guest.add(user);
				guest.add(hotel);
				guest.add(room);
				guest.add(booking);
				
				guestList.add(guest);
				
			}
		}
		catch (SQLException e) {
			throw new HotelException("Unable to fetch hotel records!!");
		}
		return null;
		
	
	}

@Override
	public List<UsersDto> getUserCredentials() throws HotelException {
	ResultSet result = null;
	int a=0;
	List<UsersDto> credentialsList = new ArrayList<UsersDto>();
	try {
		Connection con = DBUtil.getConnection();
		String query="SELECT password,role,user_name FROM users";
			PreparedStatement stmt = con.prepareStatement(query);
			result = stmt.executeQuery();
			while(result.next())
			{
			String password=result.getString(1);
			String role=result.getString(2);
			String userName=result.getString(3);
			System.out.println(password+" "+role+" "+userName);
			usersDto = new UsersDto(password,role,userName);
			credentialsList.add(usersDto);
			a++;
			}
			System.out.println("a= "+a);
			con.close();
	} catch (SQLException e) {

		throw new HotelException(e.getMessage());
		
	}catch(HotelException ue){
		throw new HotelException("Error while searching records into database");
	}
	return credentialsList;
	
}

@Override
public boolean registerUser(UsersDto usersDto) throws HotelException{
	boolean isRegistered = false;
	int result = 0;
	try {
		Connection con = DBUtil.getConnection();
		String query="insert into users values(user_id_seq.nextval,?,?,?,?,?,?,?)";

			PreparedStatement preparedSt = con.prepareStatement(query);
			preparedSt.setString(1, usersDto.getPassword());
			preparedSt.setString(2, usersDto.getRole());
			preparedSt.setString(3, usersDto.getUserName());
			preparedSt.setString(4, usersDto.getMobileNo());
			preparedSt.setString(5, usersDto.getPhone());
			preparedSt.setString(6, usersDto.getAddress());
			preparedSt.setString(7, usersDto.getEmail());
			
			result = preparedSt.executeUpdate();
			if(result > 0){
				isRegistered = true;               
			}
			con.close();
	} catch (SQLException e) {

		throw new HotelException(e.getMessage());
		
	}catch(HotelException ue){
		throw new HotelException("Error while inserting records into database");
	}
	return isRegistered;	
}

@Override
public List<String> getHotelDetails() throws HotelException {
	Connection con = DBUtil.getConnection();
	String hotelId = null;
	List<String> hotelIdList = new ArrayList<String>();
	String query="Select * from hotel";
	try {
		Statement stmt = con.createStatement();
		ResultSet rst = null;
		rst=stmt.executeQuery(query);
		while(rst.next()){
			hotelId = rst.getString(1);
			hotelIdList.add(hotelId);
		}
		System.out.println("ok");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(hotelIdList);
	return hotelIdList;
}



}
