create table users(
	user_id varchar(4), 
	password  varchar(15), 
	role varchar(10),  
	user_name varchar (25), 
	mobile_no varchar(10), 
	phone varchar(11), 
	address  varchar(25), 
	email  varchar(20));

create table hotel(
	hotel_id varchar(4), 
	city varchar(15), 
	hotel_name varchar (20), 
	address varchar(25), 
	description varchar(50), 
	avg_rate_per_night  number(7,2), 
	phone_no1 varchar(11), 
	phone_no2 varchar(11), 
	rating varchar(4), 
	email  varchar(25), 
	fax  varchar(15));


create table roomDetails(
	hotel_id varchar(4),  
	room_id  varchar(4),  
	room_no varchar(3), 
	room_type varchar(20), 
	per_night_rate  number(6,2), 
	availability  varchar(10), 
	photo blob);

create table BookingDetails(
	booking_id varchar(4), 
	room_id varchar(4),  
	user_id varchar(4), 
	booked_from  date, 
	booked_to date, 
	no_of_adults number(4), 
	no_of_children number(4), 
	amount number(6,2));