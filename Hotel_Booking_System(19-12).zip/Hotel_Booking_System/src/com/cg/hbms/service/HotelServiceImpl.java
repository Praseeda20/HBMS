package com.cg.hbms.service;

import java.util.ArrayList;
import java.util.List;
import com.cg.hbms.dao.HotelDao;
import com.cg.hbms.dao.HotelDaoImpl;
import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;

public class HotelServiceImpl implements HotelService{
	HotelDao hotelDao = new HotelDaoImpl();
	@Override
	public boolean addHotel(HotelDto hotel) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String viewHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String modifyHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addRoom(RoomDetailsDto room) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String viewRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String modifyRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<HotelDto> viewHotelList() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<RoomDetailsDto> viewRoomListHotelByHotelId()
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<BookingDetailsDto> viewBookingListByDate()
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public BookingDetailsDto viewBookingById() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<UsersDto> viewGuestListByHotelId(String hotelId)
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkCredentials(UsersDto usersDto) throws HotelException {
		List<UsersDto> userCredentialsList = hotelDao.getUserCredentials();
		boolean validUser=false;
		for(UsersDto userCredentialsList1 : userCredentialsList){
			if(userCredentialsList1.getUserName().equals(usersDto.getUserName())&&userCredentialsList1.getPassword().equals(usersDto.getPassword())&&userCredentialsList1.getRole().equals(usersDto.getRole())){
			validUser = true;
			break;
		}
			}
	return validUser;
}
}


