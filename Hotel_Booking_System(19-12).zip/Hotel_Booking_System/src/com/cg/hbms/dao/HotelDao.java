package com.cg.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;

public interface HotelDao {
	public boolean registerUser(UsersDto userDto) throws HotelException;
	public boolean addHotel(HotelDto hotelDto) throws HotelException;
	public String viewHotelId(String hotelId) throws HotelException;
	public String deleteHotelId(String hotelId) throws HotelException;
	public String modifyHotelId(String hotelId) throws HotelException;
	
	public String addRoom(RoomDetailsDto room) throws HotelException;
	public String viewRoomId(String roomId) throws HotelException;
	public String deleteRoomId(String roomId) throws HotelException ;
	public String modifyRoomId(String roomId) throws HotelException;
	
	public ArrayList<HotelDto> viewHotelList() throws HotelException;
	public ArrayList<RoomDetailsDto> viewRoomListHotelByHotelId() throws HotelException;
	public ArrayList<BookingDetailsDto> viewBookingListByDate() throws HotelException;
	public BookingDetailsDto viewBookingById() throws HotelException;
	public ArrayList<UsersDto> viewGuestListByHotelId(String hotelId) throws HotelException;
	public List<UsersDto> getUserCredentials() throws HotelException;
	
}
