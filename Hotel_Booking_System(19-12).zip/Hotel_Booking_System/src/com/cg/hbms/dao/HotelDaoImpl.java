package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.util.DBUtil;

public class HotelDaoImpl implements HotelDao{
	HotelDto hotel =  new HotelDto();
	UsersDto usersDto =  new UsersDto();
	ArrayList<UsersDto> userCredentialsList = null;
	
	@Override
	public boolean addHotel(HotelDto hotel) throws HotelException{
		boolean isInserted = false;
		int result = 0;
		
		try {
			Connection con = DBUtil.getConnection();
			String query="insert into hotel values(hotel_seq.nextval,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement preparedSt = con.prepareStatement(query);
				preparedSt.setString(1, hotel.getCity());
				preparedSt.setString(2, hotel.getHotelName());
				preparedSt.setString(3, hotel.getAddress());
				preparedSt.setString(4, hotel.getDescription());
				preparedSt.setDouble(5, hotel.getAvgRatePerNight());
				preparedSt.setString(6, hotel.getPhoneNo1());
				preparedSt.setString(7, hotel.getPhoneNo2());
				preparedSt.setString(8, hotel.getRating());
				preparedSt.setString(9, hotel.getEmail());
				preparedSt.setString(10, hotel.getFax());
				
				result = preparedSt.executeUpdate();
				if(result > 0){
					isInserted = true;
				}
				con.close();
		} catch (SQLException e) {

			throw new HotelException(e.getMessage());
			
		}catch(HotelException ue){
			throw new HotelException("Error while inserting records into database");
		}
		return isInserted;
		
		//returns the boolean value to the controller

	}

	@Override
	public String viewHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String modifyHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addRoom(RoomDetailsDto room) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String viewRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String modifyRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<HotelDto> viewHotelList() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<RoomDetailsDto> viewRoomListHotelByHotelId()
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<BookingDetailsDto> viewBookingListByDate()
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookingDetailsDto viewBookingById() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<UsersDto> viewGuestListByHotelId(String hotelId)
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}


@Override
	public List<UsersDto> getUserCredentials() throws HotelException {
	ResultSet result = null;
	
	try {
		Connection con = DBUtil.getConnection();
		String query="SELECT user_name,password,role FROM users";
			PreparedStatement stmt = con.prepareStatement(query);
			result = stmt.executeQuery();
			while(result.next())
			{
				String user=result.getString(1);
			String pass=result.getString(2);
			String userRole=result.getString(3);
			usersDto = new UsersDto(pass,userRole,user);
			userCredentialsList.add(usersDto);
			}
			con.close();
	} catch (SQLException e) {

		throw new HotelException(e.getMessage());
		
	}catch(HotelException ue){
		throw new HotelException("Error while searching records into database");
	}
	return userCredentialsList;
	
}

@Override
public boolean checkCredentials(String userName, String password, String role)
		throws HotelException {
	// TODO Auto-generated method stub
	return false;
}

}
