package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.util.DBUtil;

public class HotelDaoImpl implements HotelDao{
	HotelDto hotel =  new HotelDto();
	UsersDto usersDto =  new UsersDto();
	;
	
	@Override
	public boolean addHotel(HotelDto hotelDto) throws HotelException{
		boolean isInserted = false;
		int result = 0;
		
		try {
			Connection con = DBUtil.getConnection();
			String query="insert into hotel values(hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement preparedSt = con.prepareStatement(query);
				preparedSt.setString(1, hotelDto.getCity());
				preparedSt.setString(2, hotelDto.getHotelName());
				preparedSt.setString(3, hotelDto.getAddress());
				preparedSt.setString(4, hotelDto.getDescription());
				preparedSt.setDouble(5, hotelDto.getAvgRatePerNight());
				preparedSt.setString(6, hotelDto.getPhoneNo1());
				preparedSt.setString(7, hotelDto.getPhoneNo2());
				preparedSt.setString(8, hotelDto.getRating());
				preparedSt.setString(9, hotelDto.getEmail());
				preparedSt.setString(10, hotelDto.getFax());
				
				result = preparedSt.executeUpdate();
				if(result > 0){
					isInserted = true;
				}
				con.close();
		} catch (SQLException e) {

			throw new HotelException(e.getMessage());
			
		}catch(HotelException ue){
			throw new HotelException("Error while inserting records into database");
		}
		return isInserted;
		
		//returns the boolean value to the controller

	}

	@Override
	public String viewHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String modifyHotelId(String hotelId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addRoom(RoomDetailsDto room) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String viewRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String modifyRoomId(String roomId) throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<HotelDto> viewHotelList() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<RoomDetailsDto> viewRoomListHotelByHotelId()
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<BookingDetailsDto> viewBookingListByDate()
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookingDetailsDto viewBookingById() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<UsersDto> viewGuestListByHotelId(String hotelId)
			throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}


@Override
	public List<UsersDto> getUserCredentials() throws HotelException {
	ResultSet result = null;
	int a=0;
	List<UsersDto> credentialsList = new ArrayList<UsersDto>();
	try {
		Connection con = DBUtil.getConnection();
		String query="SELECT password,role,user_name FROM users";
			PreparedStatement stmt = con.prepareStatement(query);
			result = stmt.executeQuery();
			while(result.next())
			{
			String password=result.getString(1);
			String role=result.getString(2);
			String userName=result.getString(3);
			System.out.println(password+" "+role+" "+userName);
			usersDto = new UsersDto(password,role,userName);
			credentialsList.add(usersDto);
			a++;
			}
			System.out.println("a= "+a);
			con.close();
	} catch (SQLException e) {

		throw new HotelException(e.getMessage());
		
	}catch(HotelException ue){
		throw new HotelException("Error while searching records into database");
	}
	return credentialsList;
	
}

@Override
public boolean registerUser(UsersDto usersDto) throws HotelException{
	boolean isRegistered = false;
	int result = 0;
	try {
		Connection con = DBUtil.getConnection();
		String query="insert into users values(user_id_seq.nextval,?,?,?,?,?,?,?)";

			PreparedStatement preparedSt = con.prepareStatement(query);
			preparedSt.setString(1, usersDto.getPassword());
			preparedSt.setString(2, usersDto.getRole());
			preparedSt.setString(3, usersDto.getUserName());
			preparedSt.setString(4, usersDto.getMobileNo());
			preparedSt.setString(5, usersDto.getPhone());
			preparedSt.setString(6, usersDto.getAddress());
			preparedSt.setString(7, usersDto.getEmail());
			
			result = preparedSt.executeUpdate();
			if(result > 0){
				isRegistered = true;               
			}
			con.close();
	} catch (SQLException e) {

		throw new HotelException(e.getMessage());
		
	}catch(HotelException ue){
		throw new HotelException("Error while inserting records into database");
	}
	return isRegistered;	
}


}
