package com.cg.hbms.dao;

public class HotelDaoImpl implements HotelDao{

}
