/**
 * 
 */
package com.cg.hbms.dto;

import java.sql.Blob;

/**
 * @author Group4
 *
 */
public class RoomDetailsDTO {

	private String hotelId; 
	private String roomId; 
	private String roomNo; 
	private String roomType; 
	private double perNightRate; 
	private  boolean availability; 
	private Blob photo;
	
	/**
	 * 
	 */
	public RoomDetailsDTO() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param hotelId
	 * @param roomId
	 * @param roomNo
	 * @param roomType
	 * @param perNightRate
	 * @param availability
	 * @param photo
	 */
	public RoomDetailsDTO(String hotelId, String roomId, String roomNo,
			String roomType, double perNightRate, boolean availability,
			Blob photo) {
		
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.perNightRate = perNightRate;
		this.availability = availability;
		this.photo = photo;
	}

	/**
	 * @return the hotelId
	 */
	public String getHotelId() {
		return hotelId;
	}

	/**
	 * @param hotelId the hotelId to set
	 */
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	/**
	 * @return the roomId
	 */
	public String getRoomId() {
		return roomId;
	}

	/**
	 * @param roomId the roomId to set
	 */
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	/**
	 * @return the roomNo
	 */
	public String getRoomNo() {
		return roomNo;
	}

	/**
	 * @param roomNo the roomNo to set
	 */
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	/**
	 * @return the roomType
	 */
	public String getRoomType() {
		return roomType;
	}

	/**
	 * @param roomType the roomType to set
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	/**
	 * @return the perNightRate
	 */
	public double getPerNightRate() {
		return perNightRate;
	}

	/**
	 * @param perNightRate the perNightRate to set
	 */
	public void setPerNightRate(double perNightRate) {
		this.perNightRate = perNightRate;
	}

	/**
	 * @return the availability
	 */
	public boolean isAvailability() {
		return availability;
	}

	/**
	 * @param availability the availability to set
	 */
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	/**
	 * @return the photo
	 */
	public Blob getPhoto() {
		return photo;
	}

	/**
	 * @param photo the photo to set
	 */
	public void setPhoto(Blob photo) {
		this.photo = photo;
	}
}
