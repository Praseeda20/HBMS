/**
 * 
 */
package com.cg.hbms.dto;

import java.sql.Date;

/**
 * @author Group4
 *
 */
public class BookingDetailsDTO {

	private String bookingId; 
	private String roomId; 
	private String userId; 
	private Date bookedFrom; 
	private Date bookedTo; 
	private int noOfAdults; 
	private int noOfChildren; 
	private double amount;
	
	/**
	 * 
	 */
	public BookingDetailsDTO() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param bookingId
	 * @param roomId
	 * @param userId
	 * @param bookedFrom
	 * @param bookedTo
	 * @param noOfAdults
	 * @param noOfChildren
	 * @param amount
	 */
	public BookingDetailsDTO(String bookingId, String roomId, String userId,
			Date bookedFrom, Date bookedTo, int noOfAdults, int noOfChildren,
			double amount) {
		
		this.bookingId = bookingId;
		this.roomId = roomId;
		this.userId = userId;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}

	/**
	 * @return the bookingId
	 */
	public String getBookingId() {
		return bookingId;
	}

	/**
	 * @param bookingId the bookingId to set
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	/**
	 * @return the roomId
	 */
	public String getRoomId() {
		return roomId;
	}

	/**
	 * @param roomId the roomId to set
	 */
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the bookedFrom
	 */
	public Date getBookedFrom() {
		return bookedFrom;
	}

	/**
	 * @param bookedFrom the bookedFrom to set
	 */
	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	/**
	 * @return the bookedTo
	 */
	public Date getBookedTo() {
		return bookedTo;
	}

	/**
	 * @param bookedTo the bookedTo to set
	 */
	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}

	/**
	 * @return the noOfAdults
	 */
	public int getNoOfAdults() {
		return noOfAdults;
	}

	/**
	 * @param noOfAdults the noOfAdults to set
	 */
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	/**
	 * @return the noOfChildren
	 */
	public int getNoOfChildren() {
		return noOfChildren;
	}

	/**
	 * @param noOfChildren the noOfChildren to set
	 */
	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}
}
