/**
 * 
 */
package com.cg.hbms.dto;

/**
 * @author Group4
 *
 */
public class UsersDTO {

	private String userId;
	private String password;
	private String role;
	private String userName;
	private String mobileNo;
	private String phone; 
	private String address;
	private String email;
	
	/**
	 * 
	 */
	public UsersDTO() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param userId
	 * @param password
	 * @param role
	 * @param userName
	 * @param mobileNo
	 * @param phone
	 * @param address
	 * @param email
	 */
	public UsersDTO(String userId, String password, String role, String userName,
			String mobileNo, String phone, String address, String email) {
		
		this.userId = userId;
		this.password = password;
		this.role = role;
		this.userName = userName;
		this.mobileNo = mobileNo;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @return the user_name
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param user_name the user_name to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the mobile_no
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobile_no the mobile_no to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
}
