/**
 * 
 */
package com.cg.hbms.dao;

/**
 * @author Group4
 *
 */
public class HBMSDaoImpl implements IHBMSDao {

	/**
	 * 
	 */
	public HBMSDaoImpl() {
		// TODO Auto-generated constructor stub
	}

}
