/**
 * 
 */
package com.cg.hbms.dao;

/**
 * @author Group4
 *
 */
public interface IHBMSDao {

}
