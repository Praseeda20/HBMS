/**
 * 
 */
package com.cg.hbms.service;

/**
 * @author Group4
 *
 */
public interface IHBMSService {

}
