/**
 * 
 */
package com.cg.hbms.exception;

/**
 * @author Group4
 *
 */
public class DateException extends Exception {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 */
	public DateException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public DateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
