package com.cg.hbms.dto;

import java.util.Date;

public class GuestDto {
	
private String userName;
private String hotelName;
private String roomNo;
private String roomType;
private Date bookedFrom;
private Date bookedTo;
public GuestDto() {
	
}
public GuestDto(String userName, String hotelName, String roomNo,
		String roomType, Date bookedFrom, Date bookedTo) {
	this.userName = userName;
	this.hotelName = hotelName;
	this.roomNo = roomNo;
	this.roomType = roomType;
	this.bookedFrom = bookedFrom;
	this.bookedTo = bookedTo;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getHotelName() {
	return hotelName;
}
public void setHotelName(String hotelName) {
	this.hotelName = hotelName;
}
public String getRoomNo() {
	return roomNo;
}
public void setRoomNo(String roomNo) {
	this.roomNo = roomNo;
}
public String getRoomType() {
	return roomType;
}
public void setRoomType(String roomType) {
	this.roomType = roomType;
}
public Date getBookedFrom() {
	return bookedFrom;
}
public void setBookedFrom(Date bookedFrom) {
	this.bookedFrom = bookedFrom;
}
public Date getBookedTo() {
	return bookedTo;
}
public void setBookedTo(Date bookedTo) {
	this.bookedTo = bookedTo;
}
@Override
public String toString() {
	return "GuestDto [userName=" + userName + ", hotelName=" + hotelName
			+ ", roomNo=" + roomNo + ", roomType=" + roomType + ", bookedFrom="
			+ bookedFrom + ", bookedTo=" + bookedTo + "]";
}


}
