package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.hbms.dto.BookingDetailsDto;
import com.cg.hbms.dto.GuestDto;
import com.cg.hbms.dto.HotelDto;
import com.cg.hbms.dto.RoomDetailsDto;
import com.cg.hbms.dto.UsersDto;
import com.cg.hbms.exception.HotelException;
import com.cg.hbms.util.DBUtil;

public class HotelDaoImpl implements HotelDao {

	HotelDto hotel = new HotelDto();
	UsersDto usersDto = new UsersDto();
	RoomDetailsDto roomDto = new RoomDetailsDto();
	BookingDetailsDto bookingDto;

	@Override
	public boolean addHotel(HotelDto hotelDto) throws HotelException {
		boolean isInserted = false;
		int result = 0;

		try {

			Connection con = DBUtil.getConnection();
			String query = "insert into hotel values(hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedSt = con.prepareStatement(query);
			preparedSt.setString(1, hotelDto.getCity());
			preparedSt.setString(2, hotelDto.getHotelName());
			preparedSt.setString(3, hotelDto.getAddress());
			preparedSt.setString(4, hotelDto.getDescription());
			preparedSt.setDouble(5, hotelDto.getAvgRatePerNight());
			preparedSt.setString(6, hotelDto.getPhoneNo1());
			preparedSt.setString(7, hotelDto.getPhoneNo2());
			preparedSt.setString(8, hotelDto.getRating());
			preparedSt.setString(9, hotelDto.getEmail());
			preparedSt.setString(10, hotelDto.getFax());

			result = preparedSt.executeUpdate();

			if (result > 0) {
				isInserted = true;
			}

			con.close();
		} 
		catch (SQLException e) {
			throw new HotelException(e.getMessage());
		} 
		catch (HotelException ue) {
			throw new HotelException("Error while inserting records into database");
		}
		
		return isInserted;
	}

	@Override
	public boolean deleteHotelById(String hotelId) throws HotelException {

		Connection con = DBUtil.getConnection();

		boolean isDeleted = false;
		int result = 0;

		String query = "delete from hotel where hotel_id=(?)";

		try {
			PreparedStatement preparedSt = con.prepareStatement(query);

			preparedSt.setString(1, hotelId);

			System.out.println(hotelId);

			result = preparedSt.executeUpdate();

			if (result == 1) {
				isDeleted = true;
			}

			con.close();
		}
		catch (SQLException e) {
			throw new HotelException("Not able to delete the data");
			}

		return isDeleted;
	}

	@Override
	public boolean modifyHotelById(String hotelId, String hotelDesc)throws HotelException {
		Connection con = DBUtil.getConnection();

		boolean isModified = false;
		int result = 0;

		String query = "update hotel set description=? where hotel_id=?";

		try {
			PreparedStatement preparedSt = con.prepareStatement(query);

			preparedSt.setString(1, hotelDesc);
			preparedSt.setString(2, hotelId);

			System.out.println(hotelId);
			System.out.println(hotelDesc);

			result = preparedSt.executeUpdate();

			System.out.println("ok");
			System.out.println(result);

			if (result > 0) {
				isModified = true;
			}

			con.close();
		} 
		catch (SQLException e) {
			throw new HotelException("Not able to update the record");
			}
		
		return isModified;
	}

	@Override
	public boolean addRoom(RoomDetailsDto roomDto) throws HotelException {
		Connection con = DBUtil.getConnection();
		
		int result = 0;
		boolean isInserted = false;
		
		String sqlQuery = "insert into RoomDetails(hotel_id, room_id, room_no, room_type, per_night_rate, availability) "
				+ "values(?, room_id_seq.nextval, ?, ?, ?, ?)";

		try {
			PreparedStatement sqlStat = con.prepareStatement(sqlQuery);
		
			sqlStat.setString(1, roomDto.getHotelId());
			sqlStat.setString(2, roomDto.getRoomNo());
			sqlStat.setString(3, roomDto.getRoomType());
			sqlStat.setDouble(4, roomDto.getPerNightRate());
			sqlStat.setBoolean(5, roomDto.isAvailability());
			sqlStat.executeUpdate();
			
			result = sqlStat.executeUpdate();
			
			if (result > 0) {
				isInserted = true;
			}
			
			con.close();
		} 
		catch (SQLException e) {
			throw new HotelException("Not able to insert the Record" );
			}
		
		return isInserted;
	}

	@Override
	public boolean deleteRoomById(String hotelId, String roomId)throws HotelException {
		Connection con = DBUtil.getConnection();
		
		boolean isDeleted = false;
		int result = 0;
		
		String query = "delete from RoomDetails where hotel_id =? and room_id =?";
		
		try {
			PreparedStatement preparedSt = con.prepareStatement(query);
		
			preparedSt.setString(1, hotelId);
			preparedSt.setString(2, roomId);
			result = preparedSt.executeUpdate();
			
			if (result == 1) {
				isDeleted = true;
			}
			
			con.close();
		} 
		catch (SQLException e) {
			throw new HotelException("Not able to delete the record");
			}
		
		return isDeleted;
	}

	@Override
	public boolean modifyRoomById(String hotelId, String roomId, double perNightRate) throws HotelException {
		Connection con = DBUtil.getConnection();
		
		boolean isModified = false;
		int result = 0;
		
		String query = "update roomdetails set per_night_rate=? where hotel_id=? and room_id=?";
		
		try {
			PreparedStatement preparedSt = con.prepareStatement(query);
		
			preparedSt.setDouble(1, perNightRate);
			preparedSt.setString(2, hotelId);
			preparedSt.setString(3, roomId);
			
			result = preparedSt.executeUpdate();
			
			if (result > 0) {
				isModified = true;
			}
			
			con.close();
		} 
		catch (SQLException e) {throw new HotelException("Not able to update the record");
		
		}
		
		return isModified;
	}

	@Override
	public ArrayList<HotelDto> viewHotelList() throws HotelException {
		Connection con = DBUtil.getConnection();
		
		ArrayList<HotelDto> hotelList = new ArrayList<HotelDto>();
		
		String sqlQuery = "select * from hotel";
		
		Statement stat = null;
		ResultSet res = null;

		try {

			stat = con.createStatement();
			res = stat.executeQuery(sqlQuery);

			while (res.next()) {

				String hotelId = res.getString(1);
				String city = res.getString(2);
				String hotelName = res.getString(3);
				String address = res.getString(4);
				String description = res.getString(5);
				double avgRatePerNight = res.getDouble(6);
				String phoneNo1 = res.getString(7);
				String phoneNo2 = res.getString(8);
				String rating = res.getString(9);
				String email = res.getString(10);
				String fax = res.getString(11);
				HotelDto hotelDto = new HotelDto(hotelId, city, hotelName,
						address, description, avgRatePerNight, phoneNo1,
						phoneNo2, rating, email, fax);
				hotelList.add(hotelDto);
			}
		} 
		catch (SQLException e) {
			throw new HotelException("Unable to fetch hotel records!!");
		}

		return hotelList;
	}

	@Override
	public ArrayList<BookingDetailsDto> viewBookingListByDate(String booked_from)throws HotelException {
		Connection con = DBUtil.getConnection();
		
		ArrayList<BookingDetailsDto> bookingList = new ArrayList<BookingDetailsDto>();
		
		BookingDetailsDto booking;
		
		int result = 0;
		
		try {
			String query = "select * from BookingDetails where booked_from =?";
		
			System.out.println("select * from BookingDetails where booked_from ='"+booked_from+"'");
			
			PreparedStatement preparedSt = con.prepareStatement(query);
			
			preparedSt.setString(1, booked_from);
			
			ResultSet res = preparedSt.executeQuery();
			
			while (res.next()) {
				
				booking = new BookingDetailsDto();

				booking.setBookingId(res.getString(1));
				booking.setRoomId(res.getString(2));
				booking.setUserId(res.getString(3));
				booking.setBookedFrom(res.getDate(4));
				booking.setBookedTo(res.getDate(5));
				booking.setNoOfAdults(res.getInt(6));
				booking.setNoOfChildren(res.getInt(7));
				booking.setAmount(res.getDouble(8));

				bookingList.add(booking);
			}
		} 
		catch (SQLException e) {
			throw new HotelException("Unable to fetch Bookings!!");
		}

		return bookingList;
	}

	
	@Override
	public 	ArrayList<GuestDto> viewGuestListByHotelId(String hotelId)throws HotelException {
		Connection con = DBUtil.getConnection();
		
		ArrayList<GuestDto> guest = new ArrayList<GuestDto>();

		String sqlQuery = "select u.user_name, h.hotel_name, r.room_no, r.room_type, b.booked_from, b.booked_to"
				+ " from users u, hotel h, RoomDetails r, BookingDetails b where u.user_id = b.user_id and "
				+ "h.hotel_id= ? and r.room_id = b.room_id";
		try {
			PreparedStatement preparedSt = con.prepareStatement(sqlQuery);
			
			preparedSt.setString(1,hotelId);
			
			ResultSet res = preparedSt.executeQuery();
			System.out.println("ok1");
			while (res.next()) 
			{
				System.out.println("ok2");

				String userName= res.getString("user_name");
				String hotelName=  res.getString("hotel_name");
				String roomNo=  res.getString("room_no");
				String roomType=  res.getString("room_type");
				Date bookedFrom=  res.getDate("booked_from");
				Date bookedTo=  res.getDate("booked_to");
				System.out.println("ok3");
				 GuestDto guestDto=new GuestDto(userName,hotelName,roomNo,roomType,bookedFrom,bookedTo);
				 guest.add(guestDto);
				 System.out.println(guest);

			}
		} 
		catch (SQLException e) {
			throw new HotelException("Unable to fetch guest records!!");
		}
		
		System.out.println(guest);
		return guest;
	}

	@Override
	public List<UsersDto> getUserCredentials() throws HotelException {
		ResultSet result = null;
		int a = 0;
		
		List<UsersDto> credentialsList = new ArrayList<UsersDto>();
		
		try {
			Connection con = DBUtil.getConnection();
		
			String query = "SELECT password,role,user_name FROM users";
			
			PreparedStatement stmt = con.prepareStatement(query);
			
			result = stmt.executeQuery();
			
			while (result.next()) {
				String password = result.getString(1);
				String role = result.getString(2);
				String userName = result.getString(3);
				System.out.println(password + " " + role + " " + userName);
				usersDto = new UsersDto(password, role, userName);
				credentialsList.add(usersDto);
				a++;
			}
			System.out.println("a= " + a);
			
			con.close();
		} 
		catch (SQLException e) {
			throw new HotelException(e.getMessage());
		} 
		catch (HotelException ue) {
			throw new HotelException("Error due to wrong crendentials");
		}
		return credentialsList;
	}

	@Override
	public boolean registerUser(UsersDto usersDto) throws HotelException {
		boolean isRegistered = false;
		int result = 0;
		
		try {
			Connection con = DBUtil.getConnection();
		
			String query = "insert into users values(user_id_seq.nextval,?,?,?,?,?,?,?)";

			PreparedStatement preparedSt = con.prepareStatement(query);
			
			preparedSt.setString(1, usersDto.getPassword());
			preparedSt.setString(2, usersDto.getRole());
			preparedSt.setString(3, usersDto.getUserName());
			preparedSt.setString(4, usersDto.getMobileNo());
			preparedSt.setString(5, usersDto.getPhone());
			preparedSt.setString(6, usersDto.getAddress());
			preparedSt.setString(7, usersDto.getEmail());

			result = preparedSt.executeUpdate();
			
			if (result > 0) {
				isRegistered = true;
			}
			
			con.close();
		} 
		catch (SQLException e) {
			throw new HotelException(e.getMessage());
		} 
		catch (HotelException ue) {
			throw new HotelException("Error while registering");
		}
		
		return isRegistered;
	}

	@Override
	public List<String> getHotelDetails() throws HotelException {
		Connection con = DBUtil.getConnection();
		
		String hotelId = null;
		
		List<String> hotelIdList = new ArrayList<String>();
		
		String query = "Select * from hotel";
		
		try {
			Statement stmt = con.createStatement();
		
			ResultSet rst = null;
			rst = stmt.executeQuery(query);
			
			while (rst.next()) {
				hotelId = rst.getString(1);
				hotelIdList.add(hotelId);
			}
			
			System.out.println("ok");
		} 
		catch (SQLException e) {
			throw new HotelException("Error in fetching hotel_id");
			}
		System.out.println(hotelIdList);
		
		return hotelIdList;
	}

	@Override
	public List<BookingDetailsDto> viewBookingByHotelId(String hotelId)throws HotelException {
		List<BookingDetailsDto> hotelListById = new ArrayList<BookingDetailsDto>();
		
		String sqlQuery = "select b.booking_id, b.room_id, b.user_id ,b.booked_from ,"
				+ "b.booked_to, b.no_of_adults,b.no_of_children,"
				+ "b.amount from bookingdetails b, roomdetails r,hotel h,"
				+ "users u where h.hotel_id="+hotelId+" and b.room_id=r.room_id and r.hotel_id=h.hotel_id"
						+ " and b.user_id=u.user_id";
		
		try(Connection con = DBUtil.getConnection();
				PreparedStatement stmt = con.prepareStatement(sqlQuery);){
			
			ResultSet rst = stmt.executeQuery();
			System.out.println("executed");
			
			while(rst.next()){
				
				String bookingId = rst.getString(1);
				String roomId = rst.getString(2);
				String userId = rst.getString(3);
				Date bookedFrom = rst.getDate(4);
				Date bookedTo = rst.getDate(5);
				int noOfAdults = rst.getInt(6);
				int noOfChildren = rst.getInt(7);
				double amount = rst.getDouble(8);
				
				bookingDto = new BookingDetailsDto(bookingId,roomId, userId, bookedFrom, bookedTo, noOfAdults,noOfChildren, amount);
				hotelListById.add(bookingDto);
			}
			
			System.out.println("after while");
		} 
		catch (SQLException e) {
			throw new HotelException("Unable to fetch records!!");
		}

		return hotelListById;
	}
}