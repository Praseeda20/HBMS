package com.cg.hbms.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.hbms.exception.HotelException;

public class DBUtil {
	public static Connection getConnection() throws HotelException {
		
		InitialContext context = null;
		DataSource ds = null;
		
		try {
			context = new InitialContext();
			ds = (DataSource) context.lookup("java:/oracleDs");
			return ds.getConnection();
		}
		catch (NamingException e) {
			throw new HotelException(e.getMessage());
		}
		catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}
	}
}
