package com.cg.hbms.dao;

public interface HotelDao {

}
