package com.cg.hbms.service;

public interface HotelService {

}
