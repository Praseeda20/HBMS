package com.cg.hbms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.hbms.service.HotelService;
import com.cg.hbms.service.HotelServiceImpl;

/**
 * Servlet implementation class HotelController
 */
@WebServlet({ "/LoginPage", "/Login", "/Register", "/RegisterSuccess",
		"/ForwardAdmin","/HotelMgmnt" })
public class HotelController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public HotelController() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String url = request.getServletPath();
		// String target = "";
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		HotelService hotelService = new HotelServiceImpl();
		switch (url) {
		case "/LoginPage":
			dispatcher = request.getRequestDispatcher("jspPages/login.jsp");
			dispatcher.forward(request, response);

		case "/Login":
			
			dispatcher = request.getRequestDispatcher("jspPages/mainPage.jsp");
			dispatcher.forward(request, response);

		case "/Register":
			dispatcher = request.getRequestDispatcher("jspPages/register.jsp");
			dispatcher.forward(request, response);

		case "/RegisterSuccess":
			dispatcher = request
					.getRequestDispatcher("jspPages/RegisterSuccess.jsp");
			dispatcher.forward(request, response);

		case "/ForwardAdmin":
			String hotelMgmnt = request.getParameter("hotelMgmnt");
			System.out.println(hotelMgmnt);
			if (hotelMgmnt != null && "HOTEL MANAGEMENT".equals(hotelMgmnt)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/HotelManagement.jsp");
				dispatcher.forward(request, response);
			}
			
			String roomMgmnt = request.getParameter("roomMgmnt");
			if (roomMgmnt != null && "ROOM MANAGEMENT".equals(roomMgmnt)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/RoomManagement.jsp");
				dispatcher.forward(request, response);
			}
			
			String generateRep = request.getParameter("generateRep");
			if (generateRep != null && "GENERATE REPORTS".equals(generateRep)) {
				dispatcher = request
						.getRequestDispatcher("jspPages/GenerateReports.jsp");
				dispatcher.forward(request, response);
			}
		case "/HotelMgmnt":
			String addHotel = request.getParameter("addHotel");
			if (addHotel != null && "ADD HOTEL".equals(addHotel)) {
			dispatcher = request.getRequestDispatcher("jspPages/addHotel.jsp");
			dispatcher.forward(request, response);
		}
			String deleteHotel = request.getParameter("deleteHotel");
			if (deleteHotel != null && "DELETE HOTEL".equals(deleteHotel)) {
			dispatcher = request.getRequestDispatcher("jspPages/deleteHotel.jsp");
			dispatcher.forward(request, response);
		}	
			String modifyHotel = request.getParameter("modifyHotel");
			if (modifyHotel != null && "MODIFY HOTEL".equals(modifyHotel)) {
			dispatcher = request.getRequestDispatcher("jspPages/modifyHotel.jsp");
			dispatcher.forward(request, response);
		}
		case "/RoomMgmnt":
			String addRoom = request.getParameter("addRoom");
			if (addRoom != null && "ADD HOTEL".equals(addRoom)) {
			dispatcher = request.getRequestDispatcher("jspPages/addRoom.jsp");
			dispatcher.forward(request, response);
		}
			String deleteRoom = request.getParameter("deleteRoom");
			if (deleteRoom != null && "DELETE HOTEL".equals(deleteRoom)) {
			dispatcher = request.getRequestDispatcher("jspPages/deleteRoom.jsp");
			dispatcher.forward(request, response);
		}	
			String modifyRoom = request.getParameter("modifyRoom");
			if (modifyRoom != null && "MODIFY HOTEL".equals(modifyRoom)) {
			dispatcher = request.getRequestDispatcher("jspPages/modifyRoom.jsp");
			dispatcher.forward(request, response);
		}	
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
